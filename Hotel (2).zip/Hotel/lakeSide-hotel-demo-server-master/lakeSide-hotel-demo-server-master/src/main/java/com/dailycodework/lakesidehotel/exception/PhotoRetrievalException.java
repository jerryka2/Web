package com.dailycodework.lakesidehotel.exception;



public class PhotoRetrievalException extends RuntimeException {
    public PhotoRetrievalException(String message) {
        super(message);
    }
}
